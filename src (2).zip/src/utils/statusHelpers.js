export function getStatusBadgeClass(status) {
  switch (status) {
    case "Confirmé":   return "bg-green-100 text-green-800";
    case "En attente": return "bg-amber-100 text-amber-800";
    case "Annulé":     return "bg-red-100 text-red-800";
    case "En cours":   return "bg-blue-100 text-blue-800";
    default:           return "bg-gray-100 text-gray-800";
  }
}