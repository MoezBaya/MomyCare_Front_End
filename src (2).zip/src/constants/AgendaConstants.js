export const APPOINTMENT_STATUS_COLORS = {
  "Confirme": "#22c55e",
  "Confirmé": "#22c55e",
  "En attente": "#fb923c",
  "En cours": "#6d3ee8",
  "Annule": "#ef4444",
  "Annulé": "#ef4444",
};

export const APPOINTMENT_TYPE_THEMES = {
  consultation: {
    label: "Consultation",
    color: "#7c3aed",
    background: "#f1eaff",
    border: "#ddd0ff",
    text: "#28145f",
  },
  pregnancy: {
    label: "Suivi de grossesse",
    color: "#ec4899",
    background: "#ffe7f0",
    border: "#ffd0e1",
    text: "#6f123c",
  },
  results: {
    label: "Resultats / Examens",
    color: "#22c55e",
    background: "#dcfce7",
    border: "#bbf7d0",
    text: "#064e3b",
  },
  contraception: {
    label: "Contraception",
    color: "#fb923c",
    background: "#ffedd5",
    border: "#fed7aa",
    text: "#7c2d12",
  },
  video: {
    label: "Teleconsultation",
    color: "#3b82f6",
    background: "#dbeafe",
    border: "#bfdbfe",
    text: "#172554",
  },
  other: {
    label: "Autre",
    color: "#8b5cf6",
    background: "#ede9fe",
    border: "#ddd6fe",
    text: "#312e81",
  },
};

export const TABS = [
  { value: "calendar", label: "Calendrier" },
  { value: "availability", label: "Disponibilites" },
  { value: "appointments", label: "Rendez-vous" },
];

export const LEGEND_ITEMS = [
  { label: "Consultation", color: APPOINTMENT_TYPE_THEMES.consultation.color, shape: "dot" },
  { label: "Suivi de grossesse", color: APPOINTMENT_TYPE_THEMES.pregnancy.color, shape: "dot" },
  { label: "Resultats / Examens", color: APPOINTMENT_TYPE_THEMES.results.color, shape: "dot" },
  { label: "Contraception", color: APPOINTMENT_TYPE_THEMES.contraception.color, shape: "dot" },
  { label: "Teleconsultation", color: APPOINTMENT_TYPE_THEMES.video.color, shape: "dot" },
  { label: "Autre", color: APPOINTMENT_TYPE_THEMES.other.color, shape: "dot" },
  { label: "En cours", color: "#6d3ee8", shape: "line" },
  { label: "Confirme", color: "#22c55e", shape: "check" },
  { label: "A confirmer", color: "#fb923c", shape: "clock" },
  { label: "Note / Suivi", color: "#8b5cf6", shape: "note" },
];
