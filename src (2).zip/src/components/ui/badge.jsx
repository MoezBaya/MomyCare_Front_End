import { getStatusBadgeClass } from "@/utils/statusHelpers";

/**
 * Badge de statut réutilisable.
 * Compatible avec les imports : `Badge` et `StatusBadge`.
 */
export function StatusBadge({ status }) {
  return (
    <span
      className={`${getStatusBadgeClass(status)} text-[9px] font-bold px-1.5 py-0.5 rounded-full`}
    >
      {status}
    </span>
  );
}

// Alias pour rétrocompatibilité
export const Badge = StatusBadge;