// MomyCareLogo — SVG inline, pas de dépendance sur assets/img
export default function MomyCareLogo({ variant = "row", size = "md", className = "" }) {
  const isCol = variant === "col";

  const sizeClasses = {
    sm: { container: isCol ? "gap-1" : "gap-2", icon: "h-7 w-7", text: "text-base font-extrabold tracking-tight" },
    md: { container: isCol ? "gap-2" : "gap-3", icon: "h-10 w-10", text: "text-xl font-black tracking-tight" },
    lg: { container: isCol ? "gap-3" : "gap-4", icon: "h-16 w-16", text: "text-2xl font-black tracking-widest" },
  };

  const s = sizeClasses[size] || sizeClasses.md;

  return (
    <div
      className={`flex items-center ${isCol ? "flex-col justify-center text-center" : "flex-row"} ${s.container} ${className}`}
    >
      {/* Icône SVG inline — remplace MomyCare-picto.png */}
      <div className={`${s.icon} relative transition-transform duration-300 hover:scale-105 shrink-0`}>
        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          <rect width="40" height="40" rx="12" fill="url(#grad)" />
          {/* Croix médicale */}
          <rect x="17" y="9" width="6" height="22" rx="3" fill="white" />
          <rect x="9" y="17" width="22" height="6" rx="3" fill="white" />
          {/* Petit cœur */}
          <path d="M20 30 C20 30 14 25 14 21 C14 18.8 15.8 17 18 17 C19 17 19.8 17.5 20 18 C20.2 17.5 21 17 22 17 C24.2 17 26 18.8 26 21 C26 25 20 30 20 30Z" fill="#fda4af" opacity="0.7"/>
          <defs>
            <linearGradient id="grad" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f43f5e" />
              <stop offset="1" stopColor="#e11d48" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <span
        className={`bg-gradient-to-r from-rose-500 via-pink-500 to-rose-600 bg-clip-text text-transparent font-sans ${s.text}`}
        style={{ fontFamily: "'Inter Variable', sans-serif" }}
      >
        momycare
      </span>
    </div>
  );
}
