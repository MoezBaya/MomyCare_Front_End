import { CardTitle } from "@/components/ui/card";
import MomyCareLogo from "@/components/shared/MomyCareLogo";

export function AuthHeader({ title, subtitle }) {
  return (
    <>
      <div className="mb-4 flex justify-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-r from-rose-400 to-pink-500 shadow-lg">
          <MomyCareLogo size="sm" variant="col" className="text-white" />
        </div>
      </div>

      <CardTitle className="bg-gradient-to-r from-rose-500 to-pink-600 bg-clip-text text-center text-2xl font-bold text-transparent">
        {title}
      </CardTitle>

      {subtitle && (
        <p className="mt-2 text-center text-sm text-muted-foreground">
          {subtitle}
        </p>
      )}
    </>
  );
}
