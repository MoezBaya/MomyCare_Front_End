export function DayHeader({ date, view }) {
  const weekday = date
    .toLocaleDateString("fr-FR", { weekday: "short" })
    .replace(".", "");
  const dayMonth = date
    .toLocaleDateString("fr-FR", { day: "2-digit", month: "short" })
    .replace(".", "");

  if (view.type === "timeGridDay" || view.type === "timeGridWeek") {
    return (
      <div className="flex items-center justify-center gap-2 py-2">
        <span className="text-[12px] font-black uppercase tracking-wide text-[#1e1b4b]">
          {weekday}
        </span>
        <span className="text-[13px] font-bold text-[#5b21b6]">{dayMonth}</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center gap-1 py-2">
      <span className="text-[12px] font-black uppercase tracking-wide text-[#1e1b4b]">
        {weekday}
      </span>
      <span className="text-[13px] font-bold text-[#5b21b6]">{dayMonth}</span>
    </div>
  );
}