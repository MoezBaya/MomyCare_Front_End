import { formatTime } from "@/utils/dateHelpers";

export function SlotLabel({ date }) {
  return <span className="mc-slot-single">{formatTime(date)}</span>;
}