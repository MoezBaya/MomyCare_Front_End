import { Video } from "lucide-react";
import { getStatusBadgeClass } from "@/utils/statusHelpers";

export function EventContent({ eventInfo }) {
  const { event, timeText, view } = eventInfo;
  const patientName = event.title || "Patiente";
  const typeLabel = event.extendedProps?.type || "Consultation";
  const isVideo = event.extendedProps?.isVideoConsult;
  const status = event.extendedProps?.status || "Confirmé";
  const background = event.extendedProps?.background || "#ede9fe";

  // Vue mois
  if (view.type === "dayGridMonth") {
    return (
      <div className="mc-event-month" style={{ background }} title={`${timeText} — ${patientName}`}>
        <div className="flex items-center gap-1 mb-0.5">
          <span className="text-[10px] font-extrabold text-[#5b21b6]">{timeText}</span>
          {isVideo && <Video className="h-2.5 w-2.5 text-[#5b21b6]" />}
          <span className={`${getStatusBadgeClass(status)} text-[8px] font-bold px-1 py-0.5 rounded-full ml-auto`}>
            {status}
          </span>
        </div>
        <p className="patient-name text-[11px] leading-tight">{patientName}</p>
        <p className="event-type text-[9px] text-gray-600">{typeLabel}</p>
      </div>
    );
  }

  // Vue jour/semaine
  return (
    <div className="mc-event-inner" style={{ background }} title={`${patientName} — ${typeLabel}`}>
      <div className="flex items-center justify-between gap-1 mb-1">
        <span className="text-[10px] font-black tracking-tight text-[#5b21b6]">{timeText}</span>
        <div className="flex items-center gap-1">
          {isVideo && <Video className="h-3 w-3 shrink-0 text-[#5b21b6]" />}
          <span className={`${getStatusBadgeClass(status)} text-[9px] font-bold px-1.5 py-0.5 rounded-full`}>
            {status}
          </span>
        </div>
      </div>
      <p className="patient-name">{patientName}</p>
      <p className="event-type">{typeLabel}</p>
    </div>
  );
}