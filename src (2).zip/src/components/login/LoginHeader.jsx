import MomyCareLogo from "@/components/shared/MomyCareLogo";

export default function LoginHeader() {
  return (
    <div className="flex flex-col items-center gap-3 mb-6">
      <MomyCareLogo size="lg" variant="col" />
      <p className="text-sm text-muted-foreground">Connectez-vous à votre espace</p>
    </div>
  );
}
