import { useState } from "react";
import { Plus, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SearchInput } from "@/components/ui/SearchInput";
import { IconButton } from "@/components/ui/IconButton";
import { AgendaCalendar } from "@/components/dashboard/doctor/agenda/AgendaCalendar";
import { MiniCalendar } from "@/components/dashboard/doctor/agenda/MiniCalendar";
import { NextAppointments } from "@/components/dashboard/doctor/agenda/NextAppointments";
import { useCalendarEvents } from "@/hooks/useCalendarEvents";
import { useAvailabilities } from "@/hooks/useAvailabilities";
import { useCalendarConfig } from "@/hooks/useCalendarConfig";


export default function AgendaView() {
  const [search, setSearch] = useState("");
  
  const { events } = useCalendarEvents();
  const { availabilities, error } = useAvailabilities();
  const calendarConfig = useCalendarConfig({ events, availabilities });

  const handleEventClick = (info) => {
    console.log("Event clicked:", info.event);
  };

  const nextApps = [
    { id: "1", time: "15:30", type: "Consultation", status: "En cours" },
  ];

  if (error) return <div className="p-10 text-red-600">Erreur : {error}</div>;

  return (
    <div>
      {/* En-tête local */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-[28px] font-black text-[#1e1b4b] tracking-tight">Agenda</h1>
          <p className="text-[14px] text-[#8b87b0] mt-1">
            Gérez votre planning et vos rendez-vous
          </p>
        </div>

        <div className="flex items-center gap-3">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Rechercher une patiente..."
          />

          <IconButton icon={Bell} label="Notifications">
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-[#e11d48] border-2 border-white" />
          </IconButton>

          <Button className="h-10 px-5 rounded-[12px] bg-gradient-to-r from-[#7c3aed] to-[#6d28d9] text-white font-semibold text-[13px] hover:opacity-90 transition-opacity shadow-[0_4px_14px_rgba(124,58,237,0.25)] flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Nouvelle consultation
          </Button>
        </div>
      </div>

      {/* Contenu principal */}
      <div className="flex gap-6">
        <div className="flex-1 min-w-0">
          <AgendaCalendar config={calendarConfig} onEventClick={handleEventClick} />
        </div>
        <div className="w-[320px] shrink-0 space-y-4">
          <MiniCalendar selectedDays={[2, 3, 4, 5]} onDayClick={(day) => console.log(day)} />
          <NextAppointments appointments={nextApps} />
        </div>
      </div>
    </div>
  );
}