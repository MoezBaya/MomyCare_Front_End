// PrescriptionsView.jsx
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PrescriptionsView({ prescriptions, patients, onSavePrescription }) {
  return (
    <Card className="rounded-3xl border-pink-100 shadow-sm">
      <CardHeader>
        <CardTitle className="text-2xl font-black text-gray-900">
          Prescriptions / Médicaments
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-500">Module en cours de développement.</p>
        {/* Vous pourrez afficher ici la liste des prescriptions et un formulaire d’ajout */}
      </CardContent>
    </Card>
  );
}