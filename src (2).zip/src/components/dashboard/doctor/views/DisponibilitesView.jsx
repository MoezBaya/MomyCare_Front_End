import { useMemo, useState } from "react";

import {
  CalendarDays,
  Clock3,
  Plus,
  Trash2,
} from "lucide-react";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Button } from "@/components/ui/button";

import { Input } from "@/components/ui/input";

import { Badge } from "@/components/ui/badge";

const JOURS = [
  { value: "MONDAY", label: "Lundi" },
  { value: "TUESDAY", label: "Mardi" },
  { value: "WEDNESDAY", label: "Mercredi" },
  { value: "THURSDAY", label: "Jeudi" },
  { value: "FRIDAY", label: "Vendredi" },
  { value: "SATURDAY", label: "Samedi" },
  { value: "SUNDAY", label: "Dimanche" },
];

export default function DisponibilitesView({
  availabilities = [],
  onAddAvailability,
  onDeleteAvailability,
  isLoading = false,
}) {
  const [jourSemaine, setJourSemaine] =
    useState("MONDAY");

  const [heureDebut, setHeureDebut] =
    useState("09:00");

  const [heureFin, setHeureFin] =
    useState("17:00");

  const [status, setStatus] =
    useState("");

  const nextSlot = useMemo(
    () => availabilities?.[0] || null,
    [availabilities]
  );

  const handleSubmit = async (event) => {
    event.preventDefault();

    setStatus("");

    if (
      !jourSemaine ||
      !heureDebut ||
      !heureFin
    ) {
      setStatus(
        "Veuillez remplir tous les champs."
      );

      return;
    }

    if (heureDebut >= heureFin) {
      setStatus(
        "L'heure de fin doit être supérieure à l'heure de début."
      );

      return;
    }

    const created =
      await onAddAvailability(
        jourSemaine,
        heureDebut,
        heureFin
      );

    if (created) {
      setStatus(
        "Plage horaire ajoutée avec succès."
      );

      setJourSemaine("MONDAY");

      setHeureDebut("09:00");

      setHeureFin("17:00");
    } else {
      setStatus(
        "Impossible d'ajouter la plage."
      );
    }
  };

  return (
    <Card className="overflow-hidden rounded-[28px] border border-[#ebe7f5] bg-white shadow-[0_18px_55px_rgba(76,60,170,0.07)]">
      {/* =======================================================
          HEADER
      ======================================================= */}

      <CardHeader className="border-b border-[#f2eefb] px-6 py-5">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <CardTitle className="flex items-center gap-3 text-[24px] font-black tracking-tight text-[#1e1b4b]">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-200">
                <CalendarDays className="h-5 w-5" />
              </div>

              Disponibilités
            </CardTitle>

            <p className="mt-2 text-sm font-medium text-[#7c7aa5]">
              Gérez vos plages horaires
              hebdomadaires de consultation.
            </p>
          </div>

          {nextSlot && (
            <div className="min-w-[240px] rounded-3xl border border-[#ebe7f5] bg-[#faf8ff] px-5 py-4">
              <p className="text-xs font-black uppercase tracking-wide text-[#8b87b0]">
                Prochaine disponibilité
              </p>

              <p className="mt-2 text-sm font-extrabold text-[#1e1b4b]">
                {nextSlot.jourLibelle}
              </p>

              <div className="mt-1 flex items-center gap-2 text-sm font-semibold text-[#5b21b6]">
                <Clock3 className="h-4 w-4" />

                {nextSlot.heureDebut} —{" "}
                {nextSlot.heureFin}
              </div>
            </div>
          )}
        </div>
      </CardHeader>

      {/* =======================================================
          CONTENT
      ======================================================= */}

      <CardContent className="space-y-7 p-6">
        {/* =======================================================
            FORM
        ======================================================= */}

        <form
          onSubmit={handleSubmit}
          className="grid gap-4 rounded-[24px] border border-[#f2eefb] bg-[#fcfbff] p-5 xl:grid-cols-[1.2fr_1fr_1fr_auto]"
        >
          {/* JOUR */}

          <div className="space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wide text-[#8b87b0]">
              Jour
            </label>

            <select
              value={jourSemaine}
              onChange={(e) =>
                setJourSemaine(
                  e.target.value
                )
              }
              className="h-11 w-full rounded-2xl border border-[#ebe7f5] bg-white px-4 text-sm font-semibold text-[#1e1b4b] outline-none transition focus:border-violet-400 focus:ring-4 focus:ring-violet-100"
            >
              {JOURS.map((jour) => (
                <option
                  key={jour.value}
                  value={jour.value}
                >
                  {jour.label}
                </option>
              ))}
            </select>
          </div>

          {/* HEURE DEBUT */}

          <div className="space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wide text-[#8b87b0]">
              Heure début
            </label>

            <Input
              type="time"
              step="1800"
              value={heureDebut}
              onChange={(e) =>
                setHeureDebut(
                  e.target.value
                )
              }
              className="h-11 rounded-2xl border-[#ebe7f5] bg-white px-4 text-sm font-semibold text-[#1e1b4b] focus-visible:ring-violet-200"
            />
          </div>

          {/* HEURE FIN */}

          <div className="space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wide text-[#8b87b0]">
              Heure fin
            </label>

            <Input
              type="time"
              step="1800"
              value={heureFin}
              onChange={(e) =>
                setHeureFin(
                  e.target.value
                )
              }
              className="h-11 rounded-2xl border-[#ebe7f5] bg-white px-4 text-sm font-semibold text-[#1e1b4b] focus-visible:ring-violet-200"
            />
          </div>

          {/* BUTTON */}

          <div className="flex items-end">
            <Button
              type="submit"
              className="h-11 w-full rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 text-sm font-bold text-white shadow-lg shadow-violet-200 transition hover:scale-[1.01] hover:from-violet-700 hover:to-indigo-700"
            >
              <Plus className="mr-2 h-4 w-4" />

              Ajouter
            </Button>
          </div>
        </form>

        {/* =======================================================
            STATUS
        ======================================================= */}

        {status && (
          <div
            className={`rounded-2xl border px-4 py-3 text-sm font-semibold ${
              status.includes("succès")
                ? "border-emerald-100 bg-emerald-50 text-emerald-700"
                : "border-rose-100 bg-rose-50 text-rose-600"
            }`}
          >
            {status}
          </div>
        )}

        {/* =======================================================
            LIST HEADER
        ======================================================= */}

        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-[18px] font-black tracking-tight text-[#1e1b4b]">
              Plages actives
            </h3>

            <p className="mt-1 text-sm font-medium text-[#8b87b0]">
              {availabilities.length} plage
              {availabilities.length > 1
                ? "s"
                : ""}{" "}
              disponible
              {availabilities.length > 1
                ? "s"
                : ""}
            </p>
          </div>

          <Badge className="w-fit rounded-full border border-violet-100 bg-violet-50 px-4 py-1 text-[11px] font-bold text-violet-700 hover:bg-violet-50">
            {isLoading
              ? "Chargement..."
              : "Synchronisé"}
          </Badge>
        </div>

        {/* =======================================================
            EMPTY
        ======================================================= */}

        {availabilities.length === 0 ? (
          <div className="rounded-[24px] border border-dashed border-[#ddd6fe] bg-[#faf8ff] px-6 py-10 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-100">
              <CalendarDays className="h-6 w-6 text-violet-600" />
            </div>

            <h4 className="mt-4 text-[15px] font-black text-[#1e1b4b]">
              Aucune disponibilité
            </h4>

            <p className="mt-2 text-sm font-medium text-[#8b87b0]">
              Ajoutez vos premières plages
              horaires de consultation.
            </p>
          </div>
        ) : (
          /* =======================================================
              LIST
          ======================================================= */

          <div className="grid gap-4 lg:grid-cols-2">
            {availabilities.map((slot) => (
              <div
                key={slot.id}
                className="group flex items-center justify-between rounded-[24px] border border-[#f1eef9] bg-white px-5 py-5 shadow-[0_6px_24px_rgba(91,33,182,0.04)] transition hover:-translate-y-[1px] hover:border-violet-200"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full bg-violet-500" />

                    <p className="truncate text-[15px] font-black text-[#1e1b4b]">
                      {slot.jourLibelle}
                    </p>
                  </div>

                  <div className="mt-3 flex items-center gap-2 text-sm font-semibold text-[#5b21b6]">
                    <Clock3 className="h-4 w-4" />

                    {slot.heureDebut} —{" "}
                    {slot.heureFin}
                  </div>
                </div>

                <Button
                  type="button"
                  variant="ghost"
                  onClick={() =>
                    onDeleteAvailability(
                      slot.id
                    )
                  }
                  className="h-11 w-11 rounded-2xl text-rose-500 transition hover:bg-rose-50 hover:text-rose-600"
                >
                  <Trash2 className="h-4.5 w-4.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}