import { Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { StatusBadge } from "../../../ui/badge";

export function NextAppointments({ appointments = [] }) {
  return (
    <Card className="rounded-[24px] border border-[#ebe7f5] bg-white shadow-[0_8px_30px_rgba(76,60,170,0.06)]">
      <CardContent className="p-5">
        <h3 className="text-[15px] font-bold text-[#1e1b4b] mb-4">Prochain rendez-vous</h3>

        <div className="space-y-3">
          {appointments.map((appt) => (
            <div key={appt.id} className="flex items-center gap-3 p-3 rounded-[16px] bg-[#f8f8fc]">
              <div className="h-10 w-10 rounded-[12px] bg-[#ede9fe] flex items-center justify-center">
                <Clock className="h-5 w-5 text-[#5b21b6]" />
              </div>
              <div className="flex-1">
                <p className="text-[14px] font-bold text-[#1e1b4b]">{appt.time}</p>
                <p className="text-[12px] text-[#8b87b0]">{appt.type}</p>
              </div>
              <StatusBadge status={appt.status} />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}