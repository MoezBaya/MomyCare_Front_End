// src/components/dashboard/doctor/PatientDossierView.jsx
import { useMemo } from "react";
import {
  ArrowLeft, User, Baby, Droplet, AlertCircle, Download
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// Import des composants (vos onglets réutilisés)
import DossierTab from "./PatientDossierView/DossierTab";
import ConsultationTab from "./PatientDossierView/ConsultationTab";
import OrdonnanceTab from "./PatientDossierView/OrdonnanceTab";
import AnalyseTab from "./PatientDossierView/AnalyseTab";
import ImagerieTab from "./PatientDossierView/ImagerieTab";

export default function PatientDossierView({ patient, onBack }) {
  const age = useMemo(() => {
    if (!patient.birthday) return "";
    const birth = new Date(patient.birthday);
    const diff = Date.now() - birth.getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  }, [patient.birthday]);

  const exportToPDF = () => alert("Export PDF à implémenter");

  return (
    <div className="space-y-6 animate-fade-in max-w-6xl mx-auto py-6 px-4">
      {/* Ligne retour + en-tête patient */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack} className="rounded-2xl">
            <ArrowLeft className="h-4 w-4" /> Retour
          </Button>
          <div>
            <h2 className="text-2xl font-black text-gray-950">{patient.name}</h2>
            <p className="text-sm text-gray-500">{patient.email} · {patient.phone}</p>
          </div>
        </div>
        <Button variant="outline" onClick={exportToPDF} className="rounded-2xl border-rose-200 text-rose-600">
          <Download className="mr-2 h-4 w-4" /> Exporter PDF
        </Button>
      </div>

      {/* Cartes récapitulatives (comme dans l’image) */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <User className="h-8 w-8 text-rose-500" />
            <div><p className="text-xs text-gray-500">Âge</p><p className="text-lg font-bold">{age || "–"} ans</p></div>
          </CardContent>
        </Card>
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <Baby className="h-8 w-8 text-rose-500" />
            <div><p className="text-xs text-gray-500">Terme grossesse</p><p className="text-lg font-bold">SG {patient.weekOfPregnancy || "–"}</p></div>
          </CardContent>
        </Card>
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <Droplet className="h-8 w-8 text-rose-500" />
            <div><p className="text-xs text-gray-500">Groupe sanguin</p><p className="text-lg font-bold">{patient.bloodType || "–"}</p></div>
          </CardContent>
        </Card>
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertCircle className="h-8 w-8 text-rose-500" />
            <div><p className="text-xs text-gray-500">Allergies</p><p className="text-lg font-bold truncate">{patient.allergies || "Aucune"}</p></div>
          </CardContent>
        </Card>
      </div>

      {/* ----- Toutes les sections les unes sous les autres ----- */}
      <div className="space-y-10">
        {/* Dossier médical */}
        <section>
          <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
            📁 Dossier médical
          </h3>
          <DossierTab patienteId={patient.id} />
        </section>

        {/* Consultation */}
        <section>
          <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
            🩺 Consultation
          </h3>
          <ConsultationTab patienteId={patient.id} />
        </section>

        {/* Ordonnance */}
        <section>
          <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
            📄 Ordonnance
          </h3>
          <OrdonnanceTab patienteId={patient.id} />
        </section>

        {/* Analyses laboratoire */}
        <section>
          <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
            🔬 Analyses laboratoire
          </h3>
          <AnalyseTab patienteId={patient.id} />
        </section>

        {/* Imagerie */}
        <section>
          <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center gap-2">
            🖼️ Imagerie
          </h3>
          <ImagerieTab patienteId={patient.id} />
        </section>
      </div>

      {/* Boutons d’action finaux (comme dans l’image) */}
      <div className="flex flex-wrap gap-3 justify-end pt-6 border-t">
        <Button variant="outline" onClick={() => alert("Enregistrement global")}>
          Enregistrer le dossier
        </Button>
        <Button variant="outline" onClick={exportToPDF}>
          Imprimer
        </Button>
        <Button className="bg-rose-500 text-white" onClick={() => alert("Tout sauvegarder")}>
          Enregistrer toutes les modifications
        </Button>
      </div>
    </div>
  );
}