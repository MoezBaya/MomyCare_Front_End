import { Bell, LogOut } from "lucide-react";
import { IconButton } from "@/components/ui/IconButton";

export function TopHeader({ tabs = [], activeTab, onTabChange }) {
  return (
    <header className="h-[64px] bg-white border-b border-[#f2eefb] flex items-center justify-between px-6 shrink-0">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <svg viewBox="0 0 24 24" className="h-6 w-6 text-[#e11d48]" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
          </svg>
          <span className="text-[16px] font-black text-[#e11d48] tracking-tight">momycare</span>
        </div>

        <div className="flex items-center bg-[#f8f8fc] rounded-[12px] p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`px-4 py-2 rounded-[10px] text-[13px] font-semibold transition-all ${
                tab.id === activeTab
                  ? "bg-white text-[#1e1b4b] shadow-sm"
                  : "text-[#8b87b0] hover:text-[#1e1b4b]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <IconButton icon={Bell} label="Notifications" />
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-[#e11d48] flex items-center justify-center text-white text-[13px] font-bold">
            Dr
          </div>
          <div className="hidden md:block">
            <p className="text-[13px] font-bold text-[#1e1b4b]">Dr. BenBaya Moez</p>
            <p className="text-[11px] text-[#8b87b0]">Médecin Gynécologue</p>
          </div>
        </div>
        <IconButton
          icon={LogOut}
          className="bg-[#1e1b4b] hover:bg-[#2d2a5e]"
          label="Déconnexion"
        />
      </div>
    </header>
  );
}