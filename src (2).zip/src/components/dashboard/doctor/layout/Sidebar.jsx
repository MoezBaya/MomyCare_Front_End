import { LogOut } from "lucide-react";

export function Sidebar({ items = [], activeItem, onItemClick, onLogout }) {
  return (
    <aside className="w-[240px] h-screen bg-white border-r border-[#f2eefb] flex flex-col shrink-0">
      {/* Logo (inchangé) */}
      <div className="p-6 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <div className="h-8 w-8 rounded-[10px] bg-gradient-to-br from-[#e11d48] to-[#be123c] flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
            </svg>
          </div>
          <span className="text-[18px] font-black text-[#e11d48] tracking-tight">MomyCare</span>
        </div>
        <p className="text-[11px] text-[#8b87b0] ml-10">Espace médecin</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-2 space-y-1">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = item.id === activeItem;
          return (
            <button
              key={item.id}
              onClick={() => onItemClick(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-[16px] text-[13px] font-semibold transition-all relative ${
                isActive
                  ? "bg-[#fef2f2] text-[#e11d48] shadow-sm"
                  : "text-[#6b5b95] hover:bg-[#f8f8fc]"
              }`}
            >
              <Icon className={`h-[18px] w-[18px] ${isActive ? "text-[#e11d48]" : "text-[#8b87b0]"}`} />
              <span className="flex-1 text-left">{item.label}</span>
              {/* Badge compteur (ex: nombre de RDV) */}
              {item.badge !== undefined && (
                <span className="ml-auto bg-rose-100 text-rose-600 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Déconnexion */}
      <div className="p-3 mt-auto">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-[16px] text-[13px] font-semibold text-[#e11d48] hover:bg-[#fef2f2] transition-all"
        >
          <LogOut className="h-[18px] w-[18px]" />
          Déconnexion
        </button>
      </div>
    </aside>
  );
}