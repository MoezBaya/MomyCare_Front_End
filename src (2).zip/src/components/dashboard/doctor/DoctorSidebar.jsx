import { Sidebar } from "./layout/Sidebar";
import { navigationItems } from "@/config/navigation";

/**
 * Barre latérale spécifique au médecin.
 * Combine les items de navigation avec les compteurs (ex: RDV en attente).
 */
export function DoctorSidebar({ activeSidebar, onSelectSidebar, onLogout, counts = {} }) {
  // On enrichit chaque item avec un badge optionnel
  const itemsWithBadges = navigationItems.map((item) => {
    let badge = undefined;
    if (item.id === "rdv" && counts.rdv !== undefined) badge = counts.rdv;
    if (item.id === "patients" && counts.patients !== undefined) badge = counts.patients;
    // Ajoute d'autres correspondances si besoin
    return { ...item, badge };
  });

  return (
    <Sidebar
      items={itemsWithBadges}
      activeItem={activeSidebar}
      onItemClick={onSelectSidebar}
      onLogout={onLogout}
    />
  );
}