import { useEffect, useState } from "react";
import { Loader2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createConsultation, fetchConsultationsPatiente } from "@/services/gynecologueService";
import { Empty, Feedback, FormField, Loading, VitalsInput } from "./Shared";

export default function ConsultationTab({ patienteId }) {
  const [consultations, setConsultations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({
    motif: "",
    histoireMaladie: "",
    examenClinique: "",
    tension: "",
    poids: "",
    taille: "",
    imc: "",
    diagnostic: "",
  });

  const load = async () => {
    setLoading(true);
    try {
      const data = await fetchConsultationsPatiente(patienteId);
      setConsultations(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [patienteId]); // eslint-disable-line react-hooks/exhaustive-deps

  const updateVital = (key, val) => {
    setForm((prev) => ({ ...prev, [key]: val }));
    if (key === "poids" || key === "taille") {
      const poids = key === "poids" ? val : form.poids;
      const taille = key === "taille" ? val : form.taille;
      if (poids && taille && taille > 0) {
        const imc = (poids / ((taille / 100) ** 2)).toFixed(1);
        setForm((prev) => ({ ...prev, imc }));
      }
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await createConsultation({ ...form, patienteId });
      setMsg("Consultation ajoutee.");
      setShowForm(false);
      setForm({ motif: "", histoireMaladie: "", examenClinique: "", tension: "", poids: "", taille: "", imc: "", diagnostic: "" });
      await load();
    } catch (err) {
      setMsg("Erreur lors de l'ajout.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loading />;

  return (
    <div className="space-y-4 text-xs">
      <div className="flex justify-end">
        <Button onClick={() => setShowForm(!showForm)} className="h-9 rounded-xl bg-violet-600 px-3 text-xs font-bold text-white hover:bg-violet-700">
          <Plus className="mr-1 h-3.5 w-3.5" /> Nouvelle consultation
        </Button>
      </div>
      <Feedback msg={msg} />
      {showForm && (
        <form onSubmit={handleSubmit} className="space-y-3 rounded-xl border border-violet-100 bg-white p-4 shadow-sm">
          <h4 className="border-b border-violet-50 pb-2 text-sm font-black text-violet-700">Consultation</h4>
          <FormField label="Motif de consultation" required>
            <textarea
              rows={2}
              value={form.motif}
              onChange={(event) => setForm((current) => ({ ...current, motif: event.target.value }))}
              placeholder="Ex: Douleur pelvienne, amenorrhee, suivi de grossesse..."
              className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100"
              required
            />
          </FormField>
          <FormField label="Historique de la maladie">
            <textarea
              rows={3}
              value={form.histoireMaladie}
              onChange={(event) => setForm((current) => ({ ...current, histoireMaladie: event.target.value }))}
              placeholder="Saisir l'histoire de la maladie..."
              className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100"
            />
          </FormField>
          <FormField label="Examen clinique">
            <textarea
              rows={3}
              value={form.examenClinique}
              onChange={(event) => setForm((current) => ({ ...current, examenClinique: event.target.value }))}
              placeholder="Saisir les observations cliniques..."
              className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100"
            />
          </FormField>
          <VitalsInput values={form} onChange={updateVital} />
          <FormField label="Diagnostic / Conclusion">
            <textarea
              rows={2}
              value={form.diagnostic}
              onChange={(event) => setForm((current) => ({ ...current, diagnostic: event.target.value }))}
              placeholder="Saisir le diagnostic..."
              className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100"
            />
          </FormField>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="h-9 rounded-xl border-slate-200 px-3 text-xs">
              Annuler
            </Button>
            <Button type="submit" disabled={saving} className="h-9 rounded-xl bg-violet-600 px-3 text-xs font-bold hover:bg-violet-700">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Enregistrer"}
            </Button>
          </div>
        </form>
      )}
      {consultations.length === 0 ? (
        <Empty msg="Aucune consultation enregistree." />
      ) : (
        <div className="space-y-3">
          {consultations.map((consultation) => (
            <div key={consultation.id} className="rounded-xl border border-violet-100 bg-white p-3 shadow-sm">
              <div className="flex justify-between">
                <span className="font-black text-violet-600">#{consultation.id}</span>
                <span className="text-[11px] font-semibold text-slate-400">{new Date(consultation.createdAt).toLocaleDateString()}</span>
              </div>
              <p className="mt-1 text-sm font-bold text-slate-800">{consultation.motif || "Consultation"}</p>
              {consultation.diagnostic && <p className="mt-1 text-xs text-slate-500">{consultation.diagnostic}</p>}
              <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] font-semibold text-slate-500">
                <span>TA: {consultation.tension || "--"}</span>
                <span>Poids: {consultation.poids || "--"} kg</span>
                <span>Taille: {consultation.taille || "--"} cm</span>
                <span>IMC: {consultation.imc || "--"}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
