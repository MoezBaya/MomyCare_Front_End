import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { fetchDossierPatiente, updateDossierPatiente } from "@/services/gynecologueService";
import { FormField, Feedback, Loading, Empty } from "./Shared";

export default function DossierTab({ patienteId }) {
  const [form, setForm] = useState({ antecedents: "", allergies: "", traitementsEnCours: "", notes: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    fetchDossierPatiente(patienteId)
      .then(d => {
        if (d) {
          setForm({
            antecedents: d.antecedents || "",
            allergies: d.allergies || "",
            traitementsEnCours: d.traitementsEnCours || "",
            notes: d.notes || ""
          });
        }
      })
      .catch(() => setMsg("Dossier non trouvé"))
      .finally(() => setLoading(false));
  }, [patienteId]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateDossierPatiente(patienteId, form);
      setMsg("Dossier enregistré.");
    } catch (e) {
      setMsg("Erreur lors de la sauvegarde.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loading />;

  return (
    <div className="space-y-4">
      <Feedback msg={msg} />
      {[
        { key: "antecedents", label: "Antécédents", placeholder: "Allergies, maladies antérieures..." },
        { key: "allergies", label: "Allergies", placeholder: "Médicaments, aliments..." },
        { key: "traitementsEnCours", label: "Traitements en cours", placeholder: "Médicaments, thérapies..." },
        { key: "notes", label: "Notes", placeholder: "Informations complémentaires..." }
      ].map(({ key, label, placeholder }) => (
        <FormField key={key} label={label}>
          <textarea
            rows={3}
            value={form[key]}
            onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
            placeholder={placeholder}
            className="w-full rounded-xl border border-pink-100 p-3 text-sm"
          />
        </FormField>
      ))}
      <Button onClick={handleSave} disabled={saving} className="bg-rose-500">
        {saving ? "Enregistrement..." : "Sauvegarder"}
      </Button>
    </div>
  );
}