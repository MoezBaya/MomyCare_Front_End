import { useEffect, useState } from "react";
import { Loader2, Plus, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createOrdonnance, fetchConsultationsPatiente, fetchMedicaments, fetchOrdonnancesConsultation } from "@/services/gynecologueService";
import { Empty, Feedback, FormField, Loading } from "./Shared";

export default function OrdonnanceTab({ patienteId }) {
  const [consultations, setConsultations] = useState([]);
  const [selectedConsultId, setSelectedConsultId] = useState(null);
  const [ordonnances, setOrdonnances] = useState([]);
  const [medicaments, setMedicaments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [lignes, setLignes] = useState([{ medicamentId: "", dose: "", frequence: "", quantite: 1, duree: "", instructions: "" }]);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    Promise.all([fetchConsultationsPatiente(patienteId), fetchMedicaments()])
      .then(([consults, meds]) => {
        setConsultations(consults);
        setMedicaments(meds);
        if (consults.length) setSelectedConsultId(consults[0].id);
      })
      .finally(() => setLoading(false));
  }, [patienteId]);

  useEffect(() => {
    if (!selectedConsultId) return;
    fetchOrdonnancesConsultation(selectedConsultId).then(setOrdonnances).catch(() => setOrdonnances([]));
  }, [selectedConsultId]);

  const addLigne = () => setLignes((current) => [...current, { medicamentId: "", dose: "", frequence: "", quantite: 1, duree: "", instructions: "" }]);
  const removeLigne = (idx) => setLignes((current) => current.filter((_, index) => index !== idx));
  const updateLigne = (idx, field, value) => setLignes((current) => current.map((item, index) => (index === idx ? { ...item, [field]: value } : item)));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await createOrdonnance(selectedConsultId, { lignes, notes });
      setMsg("Ordonnance ajoutee.");
      setShowForm(false);
      setLignes([{ medicamentId: "", dose: "", frequence: "", quantite: 1, duree: "", instructions: "" }]);
      setNotes("");
      const updated = await fetchOrdonnancesConsultation(selectedConsultId);
      setOrdonnances(updated);
    } catch (err) {
      setMsg("Erreur lors de l'ajout.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loading />;
  if (!consultations.length) return <Empty msg="Aucune consultation trouvee." />;

  return (
    <div className="space-y-4 text-xs">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="w-56">
          <label className="text-[11px] font-bold text-slate-600">Consultation</label>
          <select
            value={selectedConsultId}
            onChange={(event) => setSelectedConsultId(Number(event.target.value))}
            className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium outline-none focus:border-rose-300 focus:ring-2 focus:ring-rose-100"
          >
            {consultations.map((consultation) => (
              <option key={consultation.id} value={consultation.id}>#{consultation.id} - {new Date(consultation.createdAt).toLocaleDateString()}</option>
            ))}
          </select>
        </div>
        <Button onClick={() => setShowForm(!showForm)} variant="outline" className="h-9 rounded-xl border-rose-200 bg-white px-3 text-xs font-bold text-rose-500 hover:bg-rose-50 hover:text-rose-600">
          <Plus className="mr-1 h-3.5 w-3.5" /> Ajouter un medicament
        </Button>
      </div>
      <Feedback msg={msg} />
      {showForm && (
        <form onSubmit={handleSubmit} className="space-y-3 rounded-xl border border-rose-100 bg-white p-4 shadow-sm">
          <h4 className="text-sm font-black text-rose-500">Nouvelle ordonnance</h4>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] border-collapse text-xs">
              <thead>
                <tr className="border-b border-rose-100 bg-rose-50/60 text-[11px] font-bold text-slate-600">
                  <th className="p-2 text-left">Medicament</th>
                  <th className="p-2 text-left">Dose</th>
                  <th className="p-2 text-left">Frequence</th>
                  <th className="p-2 text-left">Qte</th>
                  <th className="p-2 text-left">Duree</th>
                  <th className="p-2 text-left">Instructions</th>
                  <th className="p-2" />
                </tr>
              </thead>
              <tbody>
                {lignes.map((ligne, idx) => (
                  <tr key={idx} className="border-b border-slate-100">
                    <td className="p-2">
                      <select value={ligne.medicamentId} onChange={(event) => updateLigne(idx, "medicamentId", event.target.value)} className="h-8 w-full rounded-lg border border-slate-200 px-2 text-xs" required>
                        <option value="">Choisir</option>
                        {medicaments.map((medicament) => <option key={medicament.id} value={medicament.id}>{medicament.nom}</option>)}
                      </select>
                    </td>
                    <td className="p-2"><input value={ligne.dose} onChange={(event) => updateLigne(idx, "dose", event.target.value)} placeholder="500mg" className="h-8 w-20 rounded-lg border border-slate-200 px-2 text-xs" required /></td>
                    <td className="p-2"><input value={ligne.frequence} onChange={(event) => updateLigne(idx, "frequence", event.target.value)} placeholder="2x/j" className="h-8 w-24 rounded-lg border border-slate-200 px-2 text-xs" required /></td>
                    <td className="p-2"><input type="number" value={ligne.quantite} onChange={(event) => updateLigne(idx, "quantite", event.target.value)} min="1" className="h-8 w-14 rounded-lg border border-slate-200 px-2 text-xs" required /></td>
                    <td className="p-2"><input value={ligne.duree} onChange={(event) => updateLigne(idx, "duree", event.target.value)} placeholder="7j" className="h-8 w-20 rounded-lg border border-slate-200 px-2 text-xs" /></td>
                    <td className="p-2"><input value={ligne.instructions} onChange={(event) => updateLigne(idx, "instructions", event.target.value)} placeholder="Apres repas" className="h-8 w-32 rounded-lg border border-slate-200 px-2 text-xs" /></td>
                    <td className="p-2"><button type="button" onClick={() => removeLigne(idx)} className="grid h-8 w-8 place-items-center rounded-lg text-rose-500 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Button type="button" variant="outline" onClick={addLigne} size="sm" className="h-8 rounded-lg border-rose-200 text-xs text-rose-500 hover:bg-rose-50">
            <Plus className="mr-1 h-3 w-3" /> Ligne
          </Button>
          <FormField label="Notes pour la patiente (recommandations)">
            <textarea rows={2} value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Saisir les recommandations..." className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs outline-none focus:border-rose-300 focus:ring-2 focus:ring-rose-100" />
          </FormField>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="h-9 rounded-xl border-slate-200 px-3 text-xs">Annuler</Button>
            <Button type="submit" disabled={saving} className="h-9 rounded-xl bg-rose-500 px-3 text-xs font-bold hover:bg-rose-600">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="mr-1 h-3.5 w-3.5" />} Enregistrer
            </Button>
          </div>
        </form>
      )}
      {ordonnances.length === 0 ? (
        <Empty msg="Aucune ordonnance" />
      ) : (
        <div className="space-y-3">
          {ordonnances.map((ordonnance) => (
            <div key={ordonnance.idOrdonance} className="rounded-xl border border-rose-100 bg-white p-3 shadow-sm">
              <p className="text-sm font-black text-rose-500">Ordonnance n {ordonnance.numOrdonance}</p>
              <table className="mt-2 w-full text-xs">
                <thead><tr className="border-b border-rose-100 bg-rose-50/60 text-[11px] text-slate-600"><th className="p-2 text-left">Medicament</th><th>Dose</th><th>Frequence</th><th>Qte</th></tr></thead>
                <tbody>{ordonnance.lignes.map((ligne) => <tr key={ligne.id} className="border-b border-slate-100"><td className="p-2">{ligne.nomMedicament}</td><td>{ligne.dose}</td><td>{ligne.frequence}</td><td>{ligne.quantite}</td></tr>)}</tbody>
              </table>
              {ordonnance.notes && <p className="mt-2 text-[11px] italic text-slate-500">{ordonnance.notes}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
