import { useEffect, useState } from "react";
import { Eye, Loader2, Plus, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { addImagerie, fetchConsultationsPatiente, fetchImageriesConsultation } from "@/services/gynecologueService";
import { Empty, Feedback, FormField, Loading } from "./Shared";

export default function ImagerieTab({ patienteId }) {
  const [consultations, setConsultations] = useState([]);
  const [selectedConsultId, setSelectedConsultId] = useState(null);
  const [imageries, setImageries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [type, setType] = useState("");
  const [file, setFile] = useState(null);

  useEffect(() => {
    fetchConsultationsPatiente(patienteId).then((items) => {
      setConsultations(items);
      if (items.length) setSelectedConsultId(items[0].id);
    }).finally(() => setLoading(false));
  }, [patienteId]);

  useEffect(() => {
    if (!selectedConsultId) return;
    fetchImageriesConsultation(selectedConsultId).then(setImageries).catch(() => setImageries([]));
  }, [selectedConsultId]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!file) return setMsg("Veuillez joindre un fichier.");
    setSaving(true);
    try {
      const added = await addImagerie(selectedConsultId, { type }, file);
      setImageries((current) => [added, ...current]);
      setMsg("Imagerie ajoutee.");
      setShowForm(false);
      setType("");
      setFile(null);
    } catch (err) {
      setMsg("Erreur lors de l'ajout.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loading />;
  if (!consultations.length) return <Empty msg="Aucune consultation trouvee." />;

  return (
    <div className="space-y-4 text-xs">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="w-56">
          <label className="text-[11px] font-bold text-slate-600">Consultation</label>
          <select
            value={selectedConsultId}
            onChange={(event) => setSelectedConsultId(Number(event.target.value))}
            className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium outline-none focus:border-rose-300 focus:ring-2 focus:ring-rose-100"
          >
            {consultations.map((consultation) => (
              <option key={consultation.id} value={consultation.id}>#{consultation.id} - {new Date(consultation.createdAt).toLocaleDateString()}</option>
            ))}
          </select>
        </div>
        <Button onClick={() => setShowForm(!showForm)} variant="outline" className="h-9 rounded-xl border-rose-200 bg-white px-3 text-xs font-bold text-rose-500 hover:bg-rose-50 hover:text-rose-600">
          <Plus className="mr-1 h-3.5 w-3.5" /> Ajouter une imagerie
        </Button>
      </div>
      <Feedback msg={msg} />
      {showForm && (
        <form onSubmit={handleSubmit} className="space-y-3 rounded-xl border border-rose-100 bg-white p-4 shadow-sm">
          <h4 className="text-sm font-black text-rose-500">Nouvelle imagerie</h4>
          <FormField label="Type d'examen" required>
            <input className="h-9 w-full rounded-lg border border-slate-200 px-3 text-xs outline-none focus:border-rose-300 focus:ring-2 focus:ring-rose-100" value={type} onChange={(event) => setType(event.target.value)} required />
          </FormField>
          <FormField label="Fichier image" required>
            <input type="file" onChange={(event) => setFile(event.target.files[0])} className="text-xs" required />
          </FormField>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="h-9 rounded-xl border-slate-200 px-3 text-xs">Annuler</Button>
            <Button type="submit" disabled={saving} className="h-9 rounded-xl bg-rose-500 px-3 text-xs font-bold hover:bg-rose-600">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="mr-1 h-3.5 w-3.5" />} Ajouter
            </Button>
          </div>
        </form>
      )}
      {imageries.length === 0 ? (
        <Empty msg="Aucune imagerie" />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {imageries.map((image) => (
            <div key={image.id} className="flex items-center justify-between gap-3 rounded-xl border border-rose-100 bg-white p-3 shadow-sm">
              <div className="min-w-0">
                <p className="truncate text-sm font-black text-slate-800">{image.type}</p>
                <p className="mt-1 text-[11px] font-semibold text-slate-400">{new Date(image.dateImagerie).toLocaleDateString()}</p>
              </div>
              <button onClick={() => alert("Visualisation")} className="grid h-8 w-8 place-items-center rounded-lg bg-rose-50 text-rose-500 hover:bg-rose-100">
                <Eye className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
