export const Loading = () => <div className="text-center py-8 text-xs font-semibold text-slate-400">Chargement...</div>;
export const Empty = ({ msg }) => <div className="rounded-xl border border-dashed border-slate-200 bg-white/70 py-8 text-center text-xs font-semibold text-slate-400">{msg}</div>;
export const Feedback = ({ msg, type = "success" }) => msg ? <div className={`rounded-xl px-3 py-2 text-xs font-semibold ${type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>{msg}</div> : null;
export const FormField = ({ label, required, children }) => (
  <div className="space-y-1.5">
    <label className="text-[11px] font-bold text-slate-600">{label} {required && <span className="text-rose-500">*</span>}</label>
    {children}
  </div>
);
export const VitalsInput = ({ values, onChange }) => {
  const fields = [
    { key: "tension", label: "TA (mmHg)", placeholder: "120/80" },
    { key: "poids", label: "Poids (kg)", type: "number", step: "0.1" },
    { key: "taille", label: "Taille (cm)", type: "number", step: "1" },
    { key: "imc", label: "IMC", disabled: true, value: values.imc || "--" }
  ];
  return <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{fields.map(f => (
    <div key={f.key} className="space-y-1"><label className="text-[11px] font-bold text-slate-600">{f.label}</label>
    <input type={f.type || "text"} step={f.step} placeholder={f.placeholder} value={values[f.key] || ""} onChange={e => onChange(f.key, e.target.value)} disabled={f.disabled} className="h-9 w-full rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100 disabled:bg-slate-50" /></div>
  ))}</div>;
};
