import { useMemo } from "react";
import { ArrowLeft, User, Baby, Droplet, AlertCircle, Download } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import DossierTab from "./DossierTab";
import ConsultationTab from "./ConsultationTab";
import OrdonnanceTab from "./OrdonnanceTab";
import AnalyseTab from "./AnalyseTab";
import ImagerieTab from "./ImagerieTab";

export default function PatientDossierView({ patient, onBack }) {
  const age = useMemo(() => {
    if (!patient.birthday) return "";
    const birth = new Date(patient.birthday);
    const diff = Date.now() - birth.getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  }, [patient.birthday]);

  const exportPDF = () => alert("Export PDF");

  return (
    <div className="max-w-6xl mx-auto py-6 px-4 space-y-8">
      {/* En-tête */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack} className="rounded-2xl"><ArrowLeft className="h-4 w-4" /> Retour</Button>
          <div><h2 className="text-2xl font-black">{patient.name}</h2><p className="text-sm text-gray-500">{patient.email} · {patient.phone}</p></div>
        </div>
        <Button variant="outline" onClick={exportPDF} className="rounded-2xl border-rose-200 text-rose-600"><Download className="mr-2 h-4 w-4" /> Exporter PDF</Button>
      </div>

      {/* Cartes récapitulatives */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white"><CardContent className="p-4 flex items-center gap-3"><User className="h-8 w-8 text-rose-500" /><div><p className="text-xs text-gray-500">Âge</p><p className="text-lg font-bold">{age || "–"} ans</p></div></CardContent></Card>
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white"><CardContent className="p-4 flex items-center gap-3"><Baby className="h-8 w-8 text-rose-500" /><div><p className="text-xs text-gray-500">Terme grossesse</p><p className="text-lg font-bold">SG {patient.weekOfPregnancy || "–"}</p></div></CardContent></Card>
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white"><CardContent className="p-4 flex items-center gap-3"><Droplet className="h-8 w-8 text-rose-500" /><div><p className="text-xs text-gray-500">Groupe sanguin</p><p className="text-lg font-bold">{patient.bloodType || "–"}</p></div></CardContent></Card>
        <Card className="border-pink-100 bg-gradient-to-br from-rose-50/50 to-white"><CardContent className="p-4 flex items-center gap-3"><AlertCircle className="h-8 w-8 text-rose-500" /><div><p className="text-xs text-gray-500">Allergies</p><p className="text-lg font-bold truncate">{patient.allergies || "Aucune"}</p></div></CardContent></Card>
      </div>

      {/* Sections empilées */}
      <div className="space-y-10">
        <section><h3 className="text-xl font-bold mb-3">📁 Dossier médical</h3><DossierTab patienteId={patient.id} /></section>
        <section><h3 className="text-xl font-bold mb-3">🩺 Consultation</h3><ConsultationTab patienteId={patient.id} /></section>
        <section><h3 className="text-xl font-bold mb-3">📄 Ordonnance</h3><OrdonnanceTab patienteId={patient.id} /></section>
        <section><h3 className="text-xl font-bold mb-3">🔬 Analyses laboratoire</h3><AnalyseTab patienteId={patient.id} /></section>
        <section><h3 className="text-xl font-bold mb-3">🖼️ Imagerie</h3><ImagerieTab patienteId={patient.id} /></section>
      </div>

      {/* Boutons finaux */}
      <div className="flex justify-end gap-3 pt-6 border-t">
        <Button variant="outline" onClick={() => alert("Enregistrer")}>Enregistrer le dossier</Button>
        <Button variant="outline" onClick={exportPDF}>Imprimer</Button>
        <Button className="bg-rose-500 text-white" onClick={() => alert("Sauvegardé")}>Enregistrer toutes les modifications</Button>
      </div>
    </div>
  );
}