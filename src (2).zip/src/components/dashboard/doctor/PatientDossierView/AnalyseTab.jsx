import { useEffect, useState } from "react";
import { Loader2, Plus, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { addAnalyse, fetchAnalysesConsultation, fetchConsultationsPatiente } from "@/services/gynecologueService";
import { Empty, Feedback, FormField, Loading } from "./Shared";

export default function AnalyseTab({ patienteId }) {
  const [consultations, setConsultations] = useState([]);
  const [selectedConsultId, setSelectedConsultId] = useState(null);
  const [analyses, setAnalyses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({ examen: "", resultat: "", unite: "", ref: "", statut: "En cours" });
  const [file, setFile] = useState(null);

  useEffect(() => {
    fetchConsultationsPatiente(patienteId).then((items) => {
      setConsultations(items);
      if (items.length) setSelectedConsultId(items[0].id);
    }).finally(() => setLoading(false));
  }, [patienteId]);

  useEffect(() => {
    if (!selectedConsultId) return;
    fetchAnalysesConsultation(selectedConsultId).then(setAnalyses).catch(() => setAnalyses([]));
  }, [selectedConsultId]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!file) return setMsg("Veuillez joindre un fichier.");
    setSaving(true);
    try {
      const added = await addAnalyse(selectedConsultId, { type: form.examen, resultat: form.resultat }, file);
      setAnalyses((current) => [added, ...current]);
      setMsg("Analyse ajoutee.");
      setShowForm(false);
      setForm({ examen: "", resultat: "", unite: "", ref: "", statut: "En cours" });
      setFile(null);
    } catch (err) {
      setMsg("Erreur lors de l'ajout.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loading />;
  if (!consultations.length) return <Empty msg="Aucune consultation trouvee." />;

  return (
    <div className="space-y-4 text-xs">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="w-56">
          <label className="text-[11px] font-bold text-slate-600">Consultation</label>
          <select
            value={selectedConsultId}
            onChange={(event) => setSelectedConsultId(Number(event.target.value))}
            className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100"
          >
            {consultations.map((consultation) => (
              <option key={consultation.id} value={consultation.id}>#{consultation.id} - {new Date(consultation.createdAt).toLocaleDateString()}</option>
            ))}
          </select>
        </div>
        <Button onClick={() => setShowForm(!showForm)} variant="outline" className="h-9 rounded-xl border-violet-200 bg-white px-3 text-xs font-bold text-violet-600 hover:bg-violet-50 hover:text-violet-700">
          <Plus className="mr-1 h-3.5 w-3.5" /> Ajouter une analyse
        </Button>
      </div>
      <Feedback msg={msg} />
      {showForm && (
        <form onSubmit={handleSubmit} className="space-y-3 rounded-xl border border-violet-100 bg-white p-4 shadow-sm">
          <h4 className="text-sm font-black text-violet-700">Nouvelle analyse</h4>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
            <FormField label="Examen"><input className="h-9 w-full rounded-lg border border-slate-200 px-3 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100" value={form.examen} onChange={(event) => setForm({ ...form, examen: event.target.value })} required /></FormField>
            <FormField label="Resultat"><input className="h-9 w-full rounded-lg border border-slate-200 px-3 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100" value={form.resultat} onChange={(event) => setForm({ ...form, resultat: event.target.value })} /></FormField>
            <FormField label="Unite"><input className="h-9 w-full rounded-lg border border-slate-200 px-3 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100" value={form.unite} onChange={(event) => setForm({ ...form, unite: event.target.value })} /></FormField>
            <FormField label="Valeurs de reference"><input className="h-9 w-full rounded-lg border border-slate-200 px-3 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100" value={form.ref} onChange={(event) => setForm({ ...form, ref: event.target.value })} /></FormField>
          </div>
          <FormField label="Statut"><input className="h-9 w-full rounded-lg border border-slate-200 px-3 text-xs outline-none focus:border-violet-300 focus:ring-2 focus:ring-violet-100" value={form.statut} onChange={(event) => setForm({ ...form, statut: event.target.value })} /></FormField>
          <FormField label="Fichier" required><input type="file" onChange={(event) => setFile(event.target.files[0])} className="text-xs" required /></FormField>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="h-9 rounded-xl border-slate-200 px-3 text-xs">Annuler</Button>
            <Button type="submit" disabled={saving} className="h-9 rounded-xl bg-violet-600 px-3 text-xs font-bold hover:bg-violet-700">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="mr-1 h-3.5 w-3.5" />} Enregistrer
            </Button>
          </div>
        </form>
      )}
      {analyses.length === 0 ? (
        <Empty msg="Aucune analyse" />
      ) : (
        <div className="overflow-x-auto rounded-xl border border-violet-100 bg-white shadow-sm">
          <table className="w-full min-w-[620px] border-collapse text-xs">
            <thead>
              <tr className="border-b border-violet-100 bg-violet-50/80 text-[11px] font-bold text-slate-600">
                <th className="p-2 text-left">Examen</th>
                <th className="p-2 text-left">Resultat</th>
                <th className="p-2 text-left">Unite</th>
                <th className="p-2 text-left">Valeurs de reference</th>
                <th className="p-2 text-left">Statut</th>
              </tr>
            </thead>
            <tbody>
              {analyses.map((analyse) => (
                <tr key={analyse.id} className="border-b border-slate-100 last:border-0">
                  <td className="p-2 font-semibold text-slate-700">{analyse.type}</td>
                  <td className="p-2 text-slate-500">{analyse.resultat || "--"}</td>
                  <td className="p-2 text-slate-500">{analyse.unite || "--"}</td>
                  <td className="p-2 text-slate-500">{analyse.ref || "--"}</td>
                  <td className="p-2"><span className="rounded-full bg-green-50 px-2 py-1 text-[11px] font-bold text-green-600">{analyse.statut || "Termine"}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
