import { useState, useEffect } from "react";
import api from "@/services/api";

export function useAvailabilities() {
  const [availabilities, setAvailabilities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAvailabilities = async () => {
      try {
        // ✅ Bon endpoint : mes disponibilités du gynéco connecté
        const res = await api.get("/api/disponibilites/mes-disponibilites");

        // Extraction selon la structure de ta réponse (List<DisponibiliteDTO>)
        const data = res?.data?.body ?? res?.data?.data ?? res?.data ?? [];

        // Transformation pour l’agenda (jourSemaine, heureDebut, heureFin)
        const formatted = (Array.isArray(data) ? data : []).map((slot) => ({
          jourSemaine: slot.jourSemaine,   // ex: "MONDAY"
          heureDebut: slot.heureDebut,     // ex: "08:00"
          heureFin: slot.heureFin,         // ex: "18:00"
        }));

        setAvailabilities(formatted);
      } catch (err) {
        console.error("Erreur chargement disponibilités :", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchAvailabilities();
  }, []);

  return { availabilities, loading, error };
}