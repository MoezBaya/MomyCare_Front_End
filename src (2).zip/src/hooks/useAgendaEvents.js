

import { useMemo } from "react";
import { mapAppointmentsToCalendarEvents } from "../services/EventMapper";

export function useAgendaEvents(appointments) {
  return useMemo(
    () => mapAppointmentsToCalendarEvents(appointments),
    [appointments]
  );
}