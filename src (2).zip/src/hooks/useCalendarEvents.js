import { useCallback } from "react";
import api from "@/services/api";
import { mapAppointmentsToCalendarEvents } from "@/services/EventMapper";

export function useCalendarEvents() {
  const fetchEvents = useCallback(async (fetchInfo, successCallback, failureCallback) => {
    try {
      console.log("🔁 Chargement des rendez-vous depuis l'API...");
      const res = await api.get("/api/rdv/gyneco/mes-rdv");
      
      // 🔍 Affiche la structure réelle de la réponse (à enlever en prod)
      console.log("📦 Réponse API brute :", res);

      // Extrait le tableau de rendez-vous (robuste)
      let appointments = [];
      if (res?.data?.body && Array.isArray(res.data.body)) {
        appointments = res.data.body;
      } else if (res?.data?.data && Array.isArray(res.data.data)) {
        appointments = res.data.data;
      } else if (Array.isArray(res?.data)) {
        appointments = res.data;
      } else if (res?.data?.content && Array.isArray(res.data.content)) {
        appointments = res.data.content;
      } else {
        console.warn("⚠️ Structure de réponse inconnue, aucun tableau trouvé", res?.data);
      }

      console.log(`📋 ${appointments.length} rendez-vous récupérés`, appointments);

      // Transformation en événements FullCalendar
      const events = mapAppointmentsToCalendarEvents(appointments);
      console.log(`✅ ${events.length} événements générés`, events);

      successCallback(events);
    } catch (error) {
      console.error("❌ Erreur lors du chargement des événements :", error);
      failureCallback(error);
    }
  }, []);

  return { events: fetchEvents };
}