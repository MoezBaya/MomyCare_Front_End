import { frLocale } from "@/config/locale";
import { mapDayToIndex } from "@/utils/dateHelpers";
import { EventContent as DefaultEventContent } from "../components/calendar/renderers/EventContent";
import { DayHeader as DefaultDayHeader } from "@/components/calendar/renderers/DayHeader";
import { SlotLabel as DefaultSlotLabel } from "@/components/calendar/renderers/SlotLabel";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";

export function useCalendarConfig({ events, availabilities, customRenderers = {} }) {
  const {
    eventContent: EventContentComponent,
    slotLabelContent: SlotLabelComponent,
    dayHeaderContent: DayHeaderComponent,
  } = customRenderers;

  return {
    plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
    initialView: "timeGridDay",
    locale: frLocale,
    firstDay: 1,
    height: "auto",
    expandRows: true,
    stickyHeaderDates: true,
    slotMinTime: "08:00:00",
    slotMaxTime: "19:00:00",
    slotDuration: "00:30:00",
    slotLabelInterval: "01:00:00",
    allDaySlot: false,
    nowIndicator: true,
    eventMinHeight: 68,
    editable: true,
    selectable: true,
    events,
    businessHours: availabilities.map((slot) => ({
      daysOfWeek: [mapDayToIndex(slot.jourSemaine)],
      startTime: slot.heureDebut,
      endTime: slot.heureFin,
    })),
    dayCellClassNames: (arg) => {
      const availableDays = availabilities.map((s) => mapDayToIndex(s.jourSemaine));
      return !availableDays.includes(arg.date.getDay()) ? ["mc-disabled-day"] : [];
    },
    headerToolbar: {
      left: "prev,next today",
      center: "title",
      right: "timeGridDay,timeGridWeek,dayGridMonth",
    },
    buttonText: {
      today: "Aujourd'hui",
      month: "Mois",
      week: "Semaine",
      day: "Jour",
    },
    eventTimeFormat: { hour: "2-digit", minute: "2-digit", hour12: false },
    eventClassNames: "mc-agenda-event",
    dayMaxEvents: 3,

    eventContent: EventContentComponent
      ? (info) => <EventContentComponent eventInfo={info} />
      : (info) => <DefaultEventContent eventInfo={info} />,

    slotLabelContent: SlotLabelComponent
      ? (args) => <SlotLabelComponent date={args.date} />
      : (args) => <DefaultSlotLabel date={args.date} />,

    dayHeaderContent: DayHeaderComponent
      ? (args) => <DayHeaderComponent date={args.date} view={args.view} />
      : (args) => <DefaultDayHeader date={args.date} view={args.view} />,
  };
}