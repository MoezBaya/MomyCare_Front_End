// ─── useSelectedEvent ──────────────────────────────────────────────────
// Single Responsibility: gère uniquement la sélection d'un événement

import { useState, useCallback } from "react";

export function useSelectedEvent() {
  const [selectedEvent, setSelectedEvent] = useState(null);

  const handleEventSelection = useCallback((info) => {
    setSelectedEvent(info.event);
  }, []);

  const clearSelection = useCallback(() => {
    setSelectedEvent(null);
  }, []);

  return { selectedEvent, handleEventSelection, clearSelection };
}