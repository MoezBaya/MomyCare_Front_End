export const frLocale = {
  code: "fr",
  week: { dow: 1, doy: 4 },
  buttonText: {
    prev: "‹",
    next: "›",
    today: "Aujourd'hui",
    month: "Mois",
    week: "Semaine",
    day: "Jour",
    list: "Liste",
  },
  weekText: "Semaine",
  allDayText: "Toute la journée",
  moreLinkText: "en plus",
  noEventsText: "Aucun événement",
};