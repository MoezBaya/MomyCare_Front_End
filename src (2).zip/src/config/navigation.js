import { Home, Calendar, CalendarCheck, Clock, Users, Settings } from "lucide-react";

export const navigationItems = [
  { id: "home", label: "Accueil", icon: Home },
  { id: "agenda", label: "Agenda", icon: Calendar },
  { id: "rdv", label: "RDV", icon: CalendarCheck },
  { id: "disponibilites", label: "Disponibilités", icon: Clock },
  { id: "patients", label: "Patients", icon: Users },
  { id: "parametres", label: "Paramètres", icon: Settings },
];

export const headerTabs = [
  { id: "dashboard", label: "Tableau de bord" },
  { id: "rdv", label: "Rendez-vous" },
  { id: "profil", label: "Profil" },
];