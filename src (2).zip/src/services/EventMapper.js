import { APPOINTMENT_TYPE_THEMES } from "../constants/AgendaConstants";

function resolveAppointmentKind(rdv = {}) {
  const raw = `${rdv.type || ""} ${rdv.motif || ""} ${rdv.status || ""}`.toLowerCase();

  if (raw.includes("tele")) return "video";
  if (raw.includes("grossesse") || raw.includes("sa")) return "pregnancy";
  if (raw.includes("result") || raw.includes("analyse") || raw.includes("examen") || raw.includes("bilan")) return "results";
  if (raw.includes("contraception") || raw.includes("injection") || raw.includes("diu")) return "contraception";
  if (raw.includes("consult")) return "consultation";
  return "other";
}

// ✅ Changement ici : durée par défaut = 30 minutes (au lieu de 60)
function addDefaultEnd(startValue) {
  const start = new Date(startValue);
  if (Number.isNaN(start.getTime())) return undefined;
  // 30 minutes = 30 * 60 * 1000
  return new Date(start.getTime() + 30 * 60 * 1000).toISOString();
}

export function mapAppointmentToCalendarEvent(rdv) {
  const kind = resolveAppointmentKind(rdv);
  const theme = APPOINTMENT_TYPE_THEMES[kind] || APPOINTMENT_TYPE_THEMES.other;

  return {
    id: rdv.id,
    title: rdv.patient || "Patiente",
    start: rdv.dateRendezVous,
    end: rdv.end || addDefaultEnd(rdv.dateRendezVous), // ← now 30 min fallback
    allDay: false,
    backgroundColor: theme.background,
    borderColor: theme.border,
    textColor: theme.text,
    extendedProps: {
      ...rdv,
      kind,
      theme,
      appointmentTypeLabel: rdv.type || theme.label,
      isVideoConsult: kind === "video" || rdv.isVideoConsult,
    },
  };
}

export function mapAppointmentsToCalendarEvents(appointments = []) {
  return appointments.map(mapAppointmentToCalendarEvent);
}